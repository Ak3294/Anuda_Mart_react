import {configureStore} from '@reduxjs/toolkit';
import toggleNavReducer from '../Buyer/slices/NavBarSlice'

export const store = configureStore({
    reducer : toggleNavReducer
})