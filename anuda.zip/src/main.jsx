import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import SignIn from './Buyer/componenets/signIn/SignIn.jsx'
import SignUp from './Buyer/componenets/signUp/SignUp.jsx'
import Dashboard from './Buyer/componenets/dashboard/Dashboard.jsx'
import SellOnAnuda from './Buyer/componenets/sellOnAnuda/SellOnAnuda.jsx'
import { Provider } from 'react-redux'
import { store } from './store/Store.jsx'




  const router = createBrowserRouter([
    {
      path:'/',
      element:<App/>,
      children:[
        {
          path: '',
          element:<Dashboard/>            
        },
        {
          path: 'sign-in',
          element:<SignIn/>
        },
        {
          path:'sign-up',
          element:<SignUp/>
        },
        {
          path:'sell-on-anuda',
          element:<SellOnAnuda/>
        }
      ]
    }

  ])












ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
      <Provider store={store}>
          <RouterProvider router={router}/>
      </Provider>
  </React.StrictMode>,
)
