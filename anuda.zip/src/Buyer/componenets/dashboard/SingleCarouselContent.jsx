import React from 'react'

export default function SingleCarouselContent({color , circleClr}) {
  return (
    <>
    
    <div className={`slide h-[300px] ${color} relative mx-4 rounded-[10px] flex flex-col justify-end  sm:flex-row `} >

<div className='sm:ml-40 sm:pt-16 sm:items-start flex flex-col  items-center mb-1 w-1/2'>
  <h1 className='text-xl text-center sm:text-start lg:text-3xl font-bold mb-1'>Buy & Sell Construction Materials At <span className='text-[#e40f15] '>Best Price</span></h1>
  <p className='text-xl text-center sm:text-start lg:text-md font-extralight'>Join To Discover New Trending Products</p>

  <button className='bg-[#e40f15]  rounded-3xl p-2 w-32 text-white font-bold mt-3'>Join Now</button>
</div>
<div className='w-1/2'>
{/* <div className={`circle h-[280px] w-[280px]  ${circleClr} rounded-full  right-[25%] top-3`}>
  <img src="src/assets/images/buyer/slider-img-1.png" alt="" className='h-full object-contain '/>
</div> */}
</div>

</div>
    </>
  )
}
